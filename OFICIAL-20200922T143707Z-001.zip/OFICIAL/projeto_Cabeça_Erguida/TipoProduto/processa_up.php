<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "Mercado";


// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
$idTipo=filter_input(INPUT_GET, 'idTipo', FILTER_SANITIZE_NUMBER_INT);
$Tipo=filter_input(INPUT_GET, 'Tipo', FILTER_SANITIZE_STRING);
session_start();

$sql = "UPDATE Tipo_Produto SET Tipo='$Tipo' WHERE idTipo='$idTipo'";
$result = $conn->query($sql);
$rowusuario=mysqli_fetch_assoc($result);

if (mysqli_affected_rows($conn)) {
	$_SESSION['msg']="<center><h1> USUARIO EDITADO COM SUCESSO!</h1></center>";
	header("location:select.php");
}else{
	$_SESSION['msg']="<center><h1> HOUVE UM ERRO AO EDITAR O USUARIO</h1></center>";
	header("location:update.php");
}
?>
