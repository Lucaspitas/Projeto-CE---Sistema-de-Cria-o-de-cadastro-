<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "Mercado";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
//isset==existir
if(isset($_POST['confirmar'])){
//registro
if (!isset($_SESSION)) 
	session_start();

	//criando sessão correspondente, percorre todos os post's
	foreach ($_POST as $key => $value) 
		$_SESSION[$key]=$value;
	

	//validação
	//tamanho da sessão
		if (strlen($_SESSION['Tipo'])==0) 
		$error[]="Preencha o Tipo corretamente!";

	//inserção
if (count($error)==0) {
	$sql = "INSERT INTO Tipo_Produto (Tipo)
VALUES ('$_SESSION[Tipo]')";

$confirma=$conn->query($sql)or die($conn->error);
if ($confirma) {
	unset($_SESSION[Tipo]);
	header("location: select.php");
}else{$error[] = $confirma;}


}
if (count($error)>0) {
	echo "<div class='erro'>";
	 foreach ($error as $value)
	  echo "$valor <br>"; 
	echo "</div>";
	
}


}




?>

<form action="#" method="POST">
	<fieldset>
<legend>CADASTRO DE TIPO</legend>
		Tipo:
	<input type="text" name="Tipo"><br><br>
	<input type="submit" name="confirmar" value="Enviar" id="editar"><br></fieldset>
</form>
<center>
<a href="select.php" class="btn">Vizualizar dados</a>
<a href="../index.php" class="btn"> Pagina Principal</a></center>
<style type="text/css">
    body{margin: auto;
        font-family: 'Karla', sans-serif; }
    form {
    width: 100%;
    margin-top: 40px;
    display: flex;
    flex-direction: column;
    align-items: center;
}
form fieldset {
    width: 100%;
    max-width: 500px;
    border: 1px solid #CCC;
    padding: 10px 20px 20px 20px;
}
form fieldset legend {
    font-weight: bold;
}
form fieldset label {
    width: 100%;
}
form fieldset input {
    width: calc(100% - 22px);
    height: 40px;
    font-size: 12px;
    background-color: #FFF;
    border: 1px solid #CCC;
    margin-bottom: 10px;
    padding: 0 10px;
}
form fieldset textarea {
    width: calc(100% - 22px);
    height: 120px;
    font-size: 12px;
    background-color: #FFF;
    border: 1px solid #CCC;
    padding: 10px;
}
form #editar {
    height: 40px;
    background-color: green;
    color: #FFF;
    font-size: 20px;
    margin-top: 10px;
    padding: 0 20px;
    border: none;
    border-radius: 3px;
    cursor: pointer;
}
form #editar:hover {
   box-shadow: inset 0 0 0 5px lightgreen;

}
.btn {
    display: inline-block;
    background-color: #f44336;
    color: #FFFFFF;
    padding: 14px 25px;
    text-align: center;
    text-decoration: none;
    font-size: 16px;
    margin-left: 20px;
    opacity: 0.9;
}
a {
    margin-top: 40px;
    color: inherit;
}
a {
    background-color: transparent;
    -webkit-text-decoration-skip: objects;
}
*, *:before, *:after {
    box-sizing: inherit;
}
user agent stylesheet
a:-webkit-any-link {
    color: -webkit-link;
    cursor: pointer;
    text-decoration: underline;
}


</style>
</style>